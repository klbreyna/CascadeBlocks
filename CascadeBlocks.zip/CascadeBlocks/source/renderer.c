
#include <stdio.h>
#include <string.h>
#include "renderer.h"
#include "input.h"

// Simple software "renderer": draw colored tiles to a text background using printf-like console as fallback.
// For a proper high-quality look, we rely on grit-converted tiles in gfx/*. For this base,
// we draw rectangles via BG + sprites would be ideal; to keep it self-contained, we use a tilemap-ish approach.

// We'll use the 2D BGs: main (top) for board UI, sub (bottom) for buttons text placeholders.

static int boardX = 20; // pixels offset
static int boardY = 8;

static void draw_rect(int x, int y, int w, int h, u16 color) {
    // Very naive rectangle fill on main BG 0 in 16-bit bitmap mode would be ideal,
    // but for compatibility we use GFX FIFO: here we cheat by drawing nothing (placeholder).
    // In a full implementation, you'd set main bg to a 16-bit bitmap and write pixels.
    // This stub keeps compilation simple and avoids mode conflicts. The "look" depends on tileset when you enable it.
    (void)x; (void)y; (void)w; (void)h; (void)color;
}

void renderer_init(void) {
    // Init BGs (left minimal for now)
    // In production, set MODE_5_2D or a tile mode with grit assets.
}

void renderer_draw_splash(void) {
    // Minimal splash
    consoleSelect(&consoleSub);
    iprintf("\x1b[2J");
    iprintf("\x1b[05;04HCascadeBlocks\n");
    iprintf("\x1b[08;02HTop: Gameplay | Bottom: Touch Buttons\n");
    iprintf("\x1b[12;01HPress START to pause. L/R to hold.\n");
}

static void draw_cell(int px, int py, u16 colorIndex, GameState *g) {
    if (!colorIndex) return;
    // Placeholder: draw colored blocks as characters in debug console overlay
    // You can replace this with real tile blits using grit assets.
    consoleSelect(&console);
    iprintf("\x1b[%d;%dH#", py/8+1, px/8+1);
    (void)g;
}

void renderer_draw_board(GameState *g) {
    consoleSelect(&console);
    iprintf("\x1b[2J"); // clear top text console

    // Draw board border (text mode placeholder)
    iprintf("\x1b[01;01HScore:%7d  Lv:%2d  Lines:%3d", g->score, g->level, g->lines);

    // Draw settled grid
    for (int y=0;y<VISIBLE_H;y++) {
        for (int x=0;x<BOARD_W;x++) {
            u8 cell = g->grid[y+ (BOARD_H - VISIBLE_H)][x];
            if (cell) {
                draw_cell(boardX + x*8, boardY + y*8, cell, g);
            }
        }
    }

    // Draw ghost
    // (text placeholder, not differentiated)

    // Draw active piece
    ShapeDef *sd = &shapes[g->cur.type][g->cur.rot]; // shapes is in game.c, not visible here
    // To keep modules separated, we reconstruct cells via a helper: but for now we print a marker
    (void)sd;
    iprintf("\x1b[03;01H(Active piece at %d,%d)", g->cur.x, g->cur.y);
}

void renderer_draw_ui(GameState *g) {
    consoleSelect(&consoleSub);
    iprintf("\x1b[2J"); // clear bottom console

    // Draw button labels (touch zones)
    iprintf("\x1b[02;02HLEFT  RIGHT  DOWN  ROT>  ROT<");
    iprintf("\x1b[05;06HHOLD  HARD DROP  PAUSE");

    if (g->paused) iprintf("\x1b[10;08H-- PAUSED --");
    if (g->gameOver) iprintf("\x1b[12;08H** GAME OVER **");
    (void)g;
}
