
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "game.h"
#include "input.h"
#include "renderer.h"

static ShapeDef shapes[PIE_COUNT][4]; // rotations
static u16 default_palette[8] = {
    RGB15(0,0,0),    // 0 empty (unused)
    RGB15(29,6,6),
    RGB15(6,29,6),
    RGB15(6,6,29),
    RGB15(28,22,2),
    RGB15(23,3,25),
    RGB15(3,25,24),
    RGB15(28,9,2)
};

static int rng_state = 1;
static int rng_rand() { rng_state = (1103515245 * rng_state + 12345) & 0x7fffffff; return rng_state; }

static void bag_fill(PieceType *out, int n) {
    PieceType tmp[PIE_COUNT] = { PIE_P,PIE_Q,PIE_R,PIE_S,PIE_T,PIE_U,PIE_V };
    for (int i=0;i<PIE_COUNT;i++) {
        int j = rng_rand() % (i+1);
        PieceType pick = tmp[i];
        tmp[i]=tmp[j]; tmp[j]=pick;
    }
    for (int i=0;i<n;i++) out[i]=tmp[i%PIE_COUNT];
}

static void queue_refill(GameState *g) {
    bag_fill(g->queue, QUEUE_LEN);
}

static void make_shapes(void) {
    // Define seven distinct shapes with 4 rotations.
    // Coordinates are relative to a pivot at (0,0). We'll offset when placing.
    // P: a 3-long with a nub (like T but offset)
    int P[4][4][2] = {
        {{-1,0},{0,0},{1,0},{1,1}},
        {{0,-1},{0,0},{0,1},{1,-1}},
        {{-1,-1},{-1,0},{0,0},{1,0}},
        {{-1,1},{0,-1},{0,0},{0,1}},
    };
    int Q[4][4][2] = { // a skewed 4-long (like L variant)
        {{-1,0},{0,0},{1,0},{-1,1}},
        {{0,-1},{0,0},{0,1},{1,1}},
        {{1,-1},{-1,0},{0,0},{1,0}},
        {{-1,-1},{0,-1},{0,0},{0,1}},
    };
    int R[4][4][2] = { // a square-ish Z variant
        {{0,0},{1,0},{-1,1},{0,1}},
        {{0,-1},{0,0},{1,0},{1,1}},
        {{0,0},{1,0},{-1,1},{0,1}},
        {{0,-1},{0,0},{1,0},{1,1}},
    };
    int S[4][4][2] = { // straight 4 but with offset pivot and custom kicks
        {{-2,0},{-1,0},{0,0},{1,0}},
        {{0,-2},{0,-1},{0,0},{0,1}},
        {{-2,0},{-1,0},{0,0},{1,0}},
        {{0,-2},{0,-1},{0,0},{0,1}},
    };
    int T[4][4][2] = {
        {{-1,0},{0,0},{1,0},{0,1}},
        {{0,-1},{0,0},{0,1},{1,0}},
        {{-1,0},{0,0},{1,0},{0,-1}},
        {{0,-1},{0,0},{0,1},{-1,0}},
    };
    int U[4][4][2] = { // mirrored L-ish
        {{-1,0},{0,0},{1,0},{1,-1}},
        {{0,-1},{0,0},{0,1},{-1,1}},
        {{-1,1},{-1,0},{0,0},{1,0}},
        {{1,-1},{0,-1},{0,0},{0,1}},
    };
    int V[4][4][2] = { // small S-like
        {{-1,0},{0,0},{0,1},{1,1}},
        {{1,-1},{0,0},{1,0},{0,1}},
        {{-1,0},{0,0},{0,1},{1,1}},
        {{1,-1},{0,0},{1,0},{0,1}},
    };

    int (*defs[PIE_COUNT])[4][2] = {P,Q,R,S,T,U,V};
    u16 cols[PIE_COUNT] = { RGB15(30,6,8), RGB15(6,30,8), RGB15(6,8,30),
                            RGB15(30,22,4), RGB15(24,6,26), RGB15(6,26,28), RGB15(30,12,4) };
    for(int t=0;t<PIE_COUNT;t++){
        for(int r=0;r<4;r++){
            for(int c=0;c<4;c++){
                shapes[t][r].cells[c][0] = defs[t][r][c][0];
                shapes[t][r].cells[c][1] = defs[t][r][c][1];
            }
            shapes[t][r].color = cols[t];
        }
    }
}

static bool cell_occupied(GameState *g, int x, int y) {
    if (x<0 || x>=BOARD_W || y<0 || y>=BOARD_H) return true;
    return g->grid[y][x] != 0;
}

static bool piece_fits(GameState *g, ActivePiece *p) {
    ShapeDef *sd = &shapes[p->type][p->rot];
    for (int i=0;i<4;i++) {
        int x = p->x + sd->cells[i][0];
        int y = p->y + sd->cells[i][1];
        if (x<0 || x>=BOARD_W || y<0 || y>=BOARD_H) return false;
        if (g->grid[y][x]) return false;
    }
    return true;
}

static void piece_place(GameState *g, ActivePiece *p) {
    ShapeDef *sd = &shapes[p->type][p->rot];
    for (int i=0;i<4;i++) {
        int x = p->x + sd->cells[i][0];
        int y = p->y + sd->cells[i][1];
        if (y>=0 && y<BOARD_H && x>=0 && x<BOARD_W) g->grid[y][x] = p->type+1;
    }
}

static void spawn(GameState *g, PieceType t) {
    g->cur.type = t;
    g->cur.x = BOARD_W/2;
    g->cur.y = 1;
    g->cur.rot = 0;
    g->lockFrames = 0;
    g->holdUsed = false;
    if(!piece_fits(g,&g->cur)) g->gameOver = true;
}

static void refill_and_spawn(GameState *g) {
    queue_refill(g);
    spawn(g, g->queue[0]);
    // shift queue
    for(int i=0;i<QUEUE_LEN-1;i++) g->queue[i]=g->queue[i+1];
    g->queue[QUEUE_LEN-1]= (PieceType)(rng_rand()%PIE_COUNT);
}

static void compute_ghost(GameState *g) {
    g->ghost = g->cur;
    while (1) {
        ActivePiece test = g->ghost;
        test.y += 1;
        if (!piece_fits(g, &test)) break;
        g->ghost = test;
    }
}

static bool rotate_try(GameState *g, int dir) {
    ActivePiece test = g->cur;
    test.rot = (test.rot + (dir>0?1:3)) % 4;
    // custom small kick set
    int kicks[5][2] = {{0,0},{1,0},{-1,0},{0,-1},{0,1}};
    for (int k=0;k<5;k++) {
        ActivePiece t2 = test;
        t2.x += kicks[k][0];
        t2.y += kicks[k][1];
        if (piece_fits(g,&t2)) { g->cur = t2; return true; }
    }
    return false;
}

static int clear_lines(GameState *g) {
    int cleared=0;
    for (int y=0;y<BOARD_H;y++) {
        bool full=true;
        for (int x=0;x<BOARD_W;x++) if (!g->grid[y][x]) { full=false; break; }
        if (full) {
            cleared++;
            for (int yy=y;yy>0;yy--) memcpy(g->grid[yy], g->grid[yy-1], BOARD_W);
            memset(g->grid[0], 0, BOARD_W);
        }
    }
    return cleared;
}

static void score_lines(GameState *g, int n) {
    static int table[5]={0,100,300,500,800};
    g->score += table[n]*(g->level+1) + g->combo*50;
    g->lines += n;
    if (g->lines/10 > g->level) g->level++;
    if (n>0) g->combo++; else g->combo=0;
}

void game_init(GameState *g, int seed) {
    memset(g,0,sizeof(*g));
    memcpy(g->palette, default_palette, sizeof(default_palette));
    rng_state = seed ? seed : 1;
    make_shapes();
    queue_refill(g);
    spawn(g, g->queue[0]);
    for(int i=0;i<QUEUE_LEN-1;i++) g->queue[i]=g->queue[i+1];
    g->queue[QUEUE_LEN-1]=(PieceType)(rng_rand()%PIE_COUNT);
}

void game_update(GameState *g, int keysHeld, int keysDown, touchPosition *touch) {
    InputState in={0};
    input_read(&in, touch);

    // Horizontal move (simple DAS/ARR substitute: repeat each frame if held)
    if (in.left) { ActivePiece t=g->cur; t.x--; if (piece_fits(g,&t)) { g->cur=t; } }
    if (in.right){ ActivePiece t=g->cur; t.x++; if (piece_fits(g,&t)) { g->cur=t; } }

    // Rotate
    if (in.rotCW)  rotate_try(g, +1);
    if (in.rotCCW) rotate_try(g, -1);

    // Soft/Hard drop
    if (in.down) {
        ActivePiece t=g->cur; t.y++;
        if (piece_fits(g,&t)) { g->cur=t; g->score+=1; }
        else g->lockFrames++;
    }
    if (in.hardDrop) {
        while(1){ ActivePiece t=g->cur; t.y++; if(!piece_fits(g,&t)) break; g->cur=t; g->score+=2; }
        piece_place(g, &g->cur);
        int n = clear_lines(g);
        score_lines(g,n);
        refill_and_spawn(g);
        return;
    }

    // Hold
    if (in.hold && !g->holdUsed) {
        PieceType tmp = g->hold;
        g->hold = g->cur.type;
        g->holdUsed = true;
        if (tmp == (PieceType)0) { // empty
            refill_and_spawn(g);
        } else {
            spawn(g, tmp);
        }
    }

    // Gravity based on level
    int gravityFrames = 48 - (g->level*4); if (gravityFrames<5) gravityFrames=5;
    g->fallCounter++;
    if (g->fallCounter >= gravityFrames) {
        g->fallCounter = 0;
        ActivePiece t=g->cur; t.y++;
        if (piece_fits(g,&t)) { g->cur=t; }
        else g->lockFrames++;
    }

    // Lock if can't move down for LOCK_DELAY_FRAMES
    if (g->lockFrames >= LOCK_DELAY_FRAMES) {
        piece_place(g, &g->cur);
        int n = clear_lines(g);
        score_lines(g,n);
        refill_and_spawn(g);
        g->lockFrames = 0;
    }

    // Update ghost
    compute_ghost(g);
}

void game_draw(GameState *g) {
    renderer_draw_board(g);
    renderer_draw_ui(g);
}
