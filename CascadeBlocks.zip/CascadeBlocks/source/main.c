
#include <nds.h>
#include <stdio.h>
#include "game.h"
#include "input.h"
#include "renderer.h"

static GameState G;

int main(void) {
    // Video init
    videoSetMode(MODE_0_2D);
    videoSetModeSub(MODE_0_2D);
    vramSetMainBanks(VRAM_A_MAIN_BG, VRAM_B_MAIN_SPRITE, VRAM_C_SUB_BG, VRAM_D_SUB_SPRITE);
    lcdMainOnTop(); // gameplay on top

    consoleDemoInit(); // for quick debug on sub if needed

    renderer_init();
    renderer_draw_splash();

    // Init game
    game_init(&G, TIMER0_DATA);

    touchPosition touch;
    while (1) {
        scanKeys();
        int kDown = keysDown();
        int kHeld = keysHeld();
        touchRead(&touch);

        if (kDown & KEY_START) G.paused = !G.paused;

        if (!G.paused && !G.gameOver) {
            game_update(&G, kHeld, kDown, &touch);
        }

        game_draw(&G);

        swiWaitForVBlank();
    }
    return 0;
}
