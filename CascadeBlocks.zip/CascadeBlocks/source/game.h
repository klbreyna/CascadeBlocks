
#pragma once
#include <nds.h>
#include <stdbool.h>

#define BOARD_W 12
#define BOARD_H 22
#define VISIBLE_H 20

#define QUEUE_LEN 3
#define LOCK_DELAY_FRAMES 30
#define DAS_FRAMES 10
#define ARR_FRAMES 1

typedef enum {
    PIE_P, PIE_Q, PIE_R, PIE_S, PIE_T, PIE_U, PIE_V, // 7 custom shapes
    PIE_COUNT
} PieceType;

typedef struct {
    int8_t cells[4][2]; // up to 4 blocks: { {x,y}, ... }
    u16 color;          // 15-bit BGR
} ShapeDef;

typedef struct {
    PieceType type;
    int x, y;
    int rot; // 0..3
} ActivePiece;

typedef struct {
    u8 grid[BOARD_H][BOARD_W]; // 0 empty, otherwise color index
    u16 palette[32];           // color palette for blocks
    int score, lines, level;
    int combo;
    int fallCounter;           // frames since last gravity
    ActivePiece cur, ghost;
    PieceType hold;
    bool holdUsed;
    PieceType queue[QUEUE_LEN];
    int lockFrames;
    bool paused;
    bool gameOver;
} GameState;

// Game API
void game_init(GameState *g, int seed);
void game_update(GameState *g, int keysHeld, int keysDown, touchPosition *touch);
void game_draw(GameState *g); // implemented in renderer.c
