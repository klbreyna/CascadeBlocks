
#pragma once
#include <nds.h>

typedef struct {
    bool left, right, down, hardDrop, rotCW, rotCCW, hold, pause;
} InputState;

void input_read(InputState *in, touchPosition *touch);
bool touch_in_rect(touchPosition *t, int x, int y, int w, int h);
