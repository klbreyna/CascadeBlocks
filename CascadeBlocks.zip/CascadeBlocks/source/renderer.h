
#pragma once
#include <nds.h>
#include "game.h"

void renderer_init(void);
void renderer_draw_board(GameState *g);
void renderer_draw_ui(GameState *g);
void renderer_draw_splash(void);
