
#include "input.h"

// Touch button layout (bottom screen, 256x192)
#define BTN_W 48
#define BTN_H 40
// Rows
#define ROW1_Y 120
#define ROW2_Y 168

// Columns (gap 8)
#define X1 8
#define X2 (8+BTN_W+8)
#define X3 (8+2*(BTN_W+8))
#define X4 (8+3*(BTN_W+8))
#define X5 (8+4*(BTN_W+8))

bool touch_in_rect(touchPosition *t, int x, int y, int w, int h) {
    if (!t) return false;
    if (t->px == 0 && t->py == 0) return false;
    return (t->px >= x && t->px < x+w && t->py >= y && t->py < y+h);
}

void input_read(InputState *in, touchPosition *touch) {
    int held = keysHeld();
    int down = keysDown();

    in->left  = (held & KEY_LEFT)  || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X1, ROW1_Y, BTN_W, BTN_H));
    in->right = (held & KEY_RIGHT) || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X2, ROW1_Y, BTN_W, BTN_H));
    in->down  = (held & KEY_DOWN)  || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X3, ROW1_Y, BTN_W, BTN_H));
    in->rotCW   = (held & KEY_A)   || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X4, ROW1_Y, BTN_W, BTN_H));
    in->rotCCW  = (held & KEY_B)   || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X5, ROW1_Y, BTN_W, BTN_H));
    in->hardDrop= (held & KEY_UP)  || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X3, ROW2_Y, BTN_W, BTN_H));
    in->hold    = (held & (KEY_L|KEY_R)) || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X2, ROW2_Y, BTN_W, BTN_H));
    in->pause   = (held & KEY_START) || (keysHeld() & KEY_TOUCH && touch_in_rect(touch, X4, ROW2_Y, BTN_W, BTN_H));
}
