#pragma once
extern const unsigned int logo_Bitmap[];
extern const unsigned short logo_Pal[];
extern const unsigned int logo_Map[];
