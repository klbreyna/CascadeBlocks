#pragma once
extern const unsigned int tileset_Bitmap[];
extern const unsigned short tileset_Pal[];
extern const unsigned int tileset_Map[];
