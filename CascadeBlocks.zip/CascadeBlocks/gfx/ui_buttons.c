#include <nds.h>
const unsigned int ui_buttons_Bitmap[] = { 0 };
const unsigned short ui_buttons_Pal[] = { 0 };
const unsigned int ui_buttons_Map[] = { 0 };
