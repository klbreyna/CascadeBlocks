#include <nds.h>
const unsigned int logo_Bitmap[] = { 0 };
const unsigned short logo_Pal[] = { 0 };
const unsigned int logo_Map[] = { 0 };
