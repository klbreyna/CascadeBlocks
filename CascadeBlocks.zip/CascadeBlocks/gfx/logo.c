// Stub data for logo
const unsigned int logo_Bitmap[1] = {0};
const unsigned short logo_Pal[1] = {0};
const unsigned int logo_Map[1] = {0};
