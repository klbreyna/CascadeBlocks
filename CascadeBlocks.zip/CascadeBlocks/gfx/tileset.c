// Stub data for tileset
const unsigned int tileset_Bitmap[1] = {0};
const unsigned short tileset_Pal[1] = {0};
const unsigned int tileset_Map[1] = {0};
