#include <nds.h>
const unsigned int tileset_Bitmap[] = { 0 };
const unsigned short tileset_Pal[] = { 0 };
const unsigned int tileset_Map[] = { 0 };
