#pragma once
extern const unsigned int ui_buttons_Bitmap[];
extern const unsigned short ui_buttons_Pal[];
extern const unsigned int ui_buttons_Map[];
