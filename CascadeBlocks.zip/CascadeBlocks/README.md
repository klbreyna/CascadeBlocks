# CascadeBlocks (Nintendo DS Homebrew)

A high-quality falling-blocks game for Nintendo DS with **top-screen gameplay** and **bottom-screen touch controls**.
This is original IP (no Tetris branding/assets). It compiles to a `.nds` with devkitPro (devkitARM + libnds).

## Features
- 12×22 board (visible 20 rows), custom shapes/colors, glossed tiles
- Top screen: gameplay, score, level, lines, next queue (3), hold slot, ghost piece
- Bottom screen: big touch buttons (← → ↓ ⟳ ⟲ ⟂DROP HOLD PAUSE), plus D-Pad/ABXY support
- Gravity with levels, soft drop, hard drop, lock delay, line clear animations
- Custom rotation + wall-kick tables (not SRS), configurable in code
- Clean architecture: `game.*` (rules), `renderer.*` (draw), `input.*` (keys/touch)
- Extendable theming via `gfx/tileset.png` and `gfx/ui_buttons.png` (convert with grit)

## Build (macOS/Linux/Windows)
1. Install devkitPro: https://devkitpro.org/wiki/Getting_Started
   - Components: **devkitARM**, **libnds**, **grit**, **mmutil** (optional)
2. In a devkitPro shell:  
   ```bash
   cd CascadeBlocks
   make
   ```
   This should produce `CascadeBlocks.nds` in the project root.

### Asset conversion (grit)
We include PNGs in `gfx/`. The Makefile runs `grit` automatically to produce `.h`/`.bin` assets:
- `tileset.png` → background tile graphics + palette
- `ui_buttons.png` → sprite sheet for touch buttons
- `logo.png` → splash

If you edit art, just `make clean && make`.

## Controls
**Top screen:** Gameplay.  
**Bottom screen:** Touch buttons for LEFT, RIGHT, DOWN (soft drop), rotate CW/CCW, HARD DROP, HOLD, PAUSE.  
**Buttons:** D-Pad=move, A=rotate CW, B=rotate CCW, Down=soft drop, Up=hard drop, L/R=Hold, Start=Pause.

## Legal
This project and assets are original. It deliberately avoids Tetris trademarks/branding and uses custom rotation tables.

## TODO hooks (for your ideas)
- Powerups or special blocks (see `game.c` → `// EXTENSION: powerups`)
- Alternative piece sets or board sizes (see `game.h` constants)
- Themes (swap `gfx` and recompile)
- SFX/music via maxmod (stubs included; place samples in `data/` and enable MM in Makefile)

